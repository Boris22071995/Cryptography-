package sample;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class RegistrationController {
    @FXML
    private Button registracija;
    @FXML
    private TextField ime;
    @FXML
    private PasswordField sifra1;
    @FXML
    private PasswordField sifra2;
    String file="/home/boki95/Desktop/ProjektniKriptografija-Intellj";
    @FXML
    public void registracijaNaSistem(ActionEvent ae) {
        String hashedPassword;
        if(ime.getText().isEmpty()||sifra1.getText().isEmpty()||sifra2.getText().isEmpty()) {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Niste popunili sva polja!");
            alert.showAndWait();
        }
        if(!sifra1.getText().equals(sifra2.getText())) {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Unesene sifre se razlikuju!");
            alert.showAndWait();
        }
        String sifra=new String(sifra1.getText());
        Random rand=new Random();
        int slucajanBroj=rand.nextInt(3);
        if(slucajanBroj==1){
            hashedPassword=hashSHA512(sifra);
        }
        else if(slucajanBroj==2){
            hashedPassword=hashSHA256(sifra);
        }
        else{
            hashedPassword=hashMD5(sifra);
        }
        try{
            FileWriter fw = new FileWriter(file+"/RegistrovaniKorisnici.txt",true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);
            pw.println(ime.getText()+hashedPassword);
            pw.close();
        }catch(Exception e){e.printStackTrace();}

//        try {
//            MessageDigest md=MessageDigest.getInstance("SHA-256");
//            byte[] messageDigest=md.digest(sifra.getBytes());
//            BigInteger no = new BigInteger(1, messageDigest);
//            hashedPassword = no.toString(16);
//            while (hashedPassword.length() < 32) {
//                hashedPassword = "0" + hashedPassword;}
//            try {
//                FileWriter fw = new FileWriter(file+"/RegistrovaniKorisnici.txt",true);
//                BufferedWriter bw = new BufferedWriter(fw);
//                PrintWriter pw=new PrintWriter(bw);
//                pw.println(ime.getText()+hashedPassword);
//                pw.close();
//            }catch(Exception exe){
//                exe.printStackTrace();
//            }
//        }catch(Exception ex) {
//            ex.printStackTrace();
//        }
        String imeHashed="";
//        Random rand =new Random();
//        int slucajanBroj=rand.nextInt(3);
//        if(slucajanBroj==1){
//            imeHashed=hashSHA512(ime.getText());
//        }else if(slucajanBroj==2){
//            imeHashed=hashSHA256(ime.getText());
//        }else{
//            imeHashed=hashMD5(ime.getText());
//        }
//        new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+imeHashed).mkdir();
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(ime.getText().getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            imeHashed = no.toString(16);
            while (imeHashed.length() < 32) {
                imeHashed = "0" + imeHashed;}
            new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+imeHashed).mkdir();
        }catch(Exception i) {i.printStackTrace();}
        ime.setText(null);
        sifra1.setText(null);
        sifra2.setText(null);
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Scene scene = new Scene(root,463,270);
            Stage stage = (Stage) ((Node) ae.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(false);
            stage.setTitle("CryptoChat");
            stage.show();
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
    public String hashSHA512(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashMD5(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
}
