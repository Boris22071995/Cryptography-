package sample;
import javafx.scene.control.ChoiceBox;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
public class OnlineUsersWatcher extends Thread {
    private final File file;
    private List<String>lista;
    private ChoiceBox cBox;
    private static UserModeController userController;
    private AtomicBoolean stop= new AtomicBoolean(false);
    public OnlineUsersWatcher(File file,List l,UserModeController u){
        this.file=file;
        this.lista=l;
        this.userController=u;
    }
    public boolean isStopeped(){
        return stop.get();
    }
    public void stopThread(){
        stop.set(true);
    }
    public void doOnChange() throws IOException {
        List<String> list = userController.onlineUsers();
        userController.setChoiceBox(list);
    }
    @Override
    public void run(){
        try(WatchService watcher= FileSystems.getDefault().newWatchService()){
            Path path=file.toPath().getParent();
            path.register(watcher, StandardWatchEventKinds.ENTRY_MODIFY);
            while(!isStopeped()){
                WatchKey key;
                try{
                    key=watcher.poll(10, TimeUnit.MINUTES);
                }catch(InterruptedException e){return;}
                if(key==null){Thread.yield();continue;}
                Thread.sleep(50);
                for(WatchEvent<?> event:key.pollEvents()){
                    WatchEvent.Kind<?> kind =event.kind();
                    @SuppressWarnings("unchecked")
                            WatchEvent<Path> ev=(WatchEvent<Path>)event;
                    Path filename=ev.context();
                    if(kind==StandardWatchEventKinds.OVERFLOW){
                        Thread.yield();
                        continue;
                    }else if(kind== StandardWatchEventKinds.ENTRY_MODIFY&&filename.toString().equals(file.getName())){
                        doOnChange();
                    }
                    boolean valid=key.reset();
                    if(!valid){break;}
                }
                Thread.yield();
            }

        }catch(Throwable e){}
    }
}
