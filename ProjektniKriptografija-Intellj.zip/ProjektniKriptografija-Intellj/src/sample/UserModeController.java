package sample;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.*;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.*;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class UserModeController implements Initializable {
    @FXML
    private ChoiceBox cbox;
    @FXML
    private TextArea tArea;
    @FXML
    private TextField tField;
    @FXML
    private Button posalji;
    @FXML
    private Button konekcija;
    @FXML
    private Label labela;
    @FXML
    private Button odjava;
    private byte[]input;
    private String potpisFajla="";
    private boolean uspostavljenaKonekcija=false;
    private String sagovornik;
    private List<String> list;
    private User korisnik=new User();
    private String algoritam=korisnik.getAlgoritam();
    private String kljuc=korisnik.getKljuc();
    private byte[] keyValue;
    private static OnlineUsersWatcher onlineWatcher;
    private String algoritamSagovornika="";
    private String kljucSagovornika="";
    public byte[] keyValueSagovornik;
    public void kreirajAlgoritamIKljucSagovornika(){
        if(algoritamSagovornika.contentEquals("AES"))
        {
            while(kljucSagovornika.length() < 16)
                kljucSagovornika += kljucSagovornika;
            kljucSagovornika = kljucSagovornika.substring(0,16);
            keyValueSagovornik = kljucSagovornika.getBytes();
        }
        else if(algoritamSagovornika.contentEquals("DES")||algoritamSagovornika.contentEquals("Blowfish")) {
            while(kljucSagovornika.length() < 8)
                kljucSagovornika += kljucSagovornika;
            kljucSagovornika = kljucSagovornika.substring(0,8);
            keyValueSagovornik = kljucSagovornika.getBytes();
        }
    }
    private Key generateKeySagovornika(){
        Key key=new SecretKeySpec(keyValueSagovornik,algoritamSagovornika);
        return key;
    }
    public void kreirajAlgoritamIKljuc() {

        if(algoritam.contentEquals("AES"))
        {
            while(kljuc.length() < 16)
                kljuc += kljuc;
            kljuc = kljuc.substring(0,16);
            keyValue = kljuc.getBytes();
        }
        else if(algoritam.contentEquals("DES")||algoritam.contentEquals("Blowfish")) {
            while(kljuc.length() < 8)
                kljuc += kljuc;
            kljuc = kljuc.substring(0,8);
            keyValue = kljuc.getBytes();
        }
    }
    public String getKorisnikName(){return korisnik.getName();}
    public String getSagovornik(){return sagovornik;}
    public String encrypt(String data) {
        kreirajAlgoritamIKljucSagovornika();
        Key key = generateKeySagovornika();
        Cipher c;
        try {
            c = Cipher.getInstance(algoritamSagovornika);
            c.init(Cipher.ENCRYPT_MODE, key);
            byte[] encVal = c.doFinal(data.getBytes());
            byte[] eValue = Base64.getEncoder().encode(encVal);
            String encryptedValue = new String(eValue);
            return encryptedValue;
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
            return null;
        }
    }
    public  String decrypt(String strEncrypted) {
        kreirajAlgoritamIKljuc();
       String strData = "";
        try {
            Key key = new SecretKeySpec(keyValue, algoritam);
            Cipher cipher = Cipher.getInstance(algoritam);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(strEncrypted));
            strData = new String(decrypted);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strData;
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        labela.setText(korisnik.getName());
        tField.setDisable(true);
        List<String>l=onlineUsers();
        cbox.setItems(FXCollections.observableList(l));
    }
    @FXML
    public void posalji() throws Exception {
        long pocetak = System.currentTimeMillis();

        Date instant=new Date(pocetak);
        SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm" );
        String time = sdf.format( instant );
        String hashSagovornika=hashSHA256(sagovornik);
        String mojHash=hashSHA256(getKorisnikName());
        PrivateKey mojPrivK=getPemPrivateKey("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/" + mojHash + "4096.key");
        File zaJavni=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/" + hashSagovornika + ".pem");
        PublicKey pubK=getCertificate(zaJavni).getPublicKey();
        if(uspostavljenaKonekcija){
            String poruka=tField.getText();
            tArea.appendText("ja: " +poruka+"          "+time+"\n");
            tField.setText(null);
            String kriptovanaPoruka=encrypt(poruka);
            File file=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + hashSagovornika + "/cryptovano.txt");
            FileWriter fw2=new FileWriter("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + hashSagovornika + "/cryptovano.txt");
            BufferedWriter bw2=new BufferedWriter(fw2);
            PrintWriter pw2=new PrintWriter(bw2);
            pw2.println(kriptovanaPoruka);
            pw2.flush();
            pw2.close();
            String signat=sign(file,mojPrivK,"SHA512withRSA");
            encryptAsymmetric(pubK,getFileInBytes(file),file);
            FileWriter f23=new FileWriter("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + hashSagovornika + "/signature.txt");
            BufferedWriter b23=new BufferedWriter(f23);
            PrintWriter p23=new PrintWriter(b23);
            p23.print(signat);
            p23.flush();
            p23.close();
            FileWriter fw = new FileWriter("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + hashSagovornika + "/poruka.txt");
            BufferedWriter bw=new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);
            pw.println(kriptovanaPoruka);
            pw.flush();
            pw.close();

        }else{
            Alert alert=new Alert(Alert.AlertType.ERROR);
              alert.setHeaderText(null);
              alert.setContentText("Konekcija nije uspostavljena");
              alert.showAndWait();
              tField.setText(null);
              tField.setDisable(true);
        }
    }
    @FXML
    public void odjaviKorisnika(ActionEvent ae){
        int brojac=0;
        List<String> lines = new ArrayList<String>();
        File file=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/PrijavljeniKorisnici.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = br.readLine();
            while (line != null)
            {
                lines.add(line);
                line = br.readLine();
                brojac++;
            }
            file.delete();
        }catch(IOException eio) {eio.printStackTrace();}
        try {
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw=new PrintWriter(bw);
            for(int i=0;i<brojac;i++)
            {
                String text=new String(lines.remove(0));
                if(!(text.contentEquals(korisnik.getName())))
                    pw.println(text);
            }
            pw.close();
        }catch(IOException oi) {oi.printStackTrace();
        }
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Scene scene = new Scene(root,463,265);
            Stage stage = (Stage) ((Node) ae.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("CryptoChat");
            stage.show();
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
    public void postaviPodatkeIzSluke(String algoritam,String kljuc){
        this.algoritamSagovornika=algoritam;
        this.kljucSagovornika=kljuc;
    }
    private void watchOnlineUsers(ChoiceBox box) {
        File fajl = new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/PrijavljeniKorisnici.txt");
        OnlineUsersWatcher watcher=new OnlineUsersWatcher(fajl,list,this);
        if (fajl.exists()) {
            Thread nit = new Thread(watcher);
            nit.setDaemon(true);
            nit.start();
        }
    }
    public  void izmjeni(File file) throws IOException {
        Runnable akcija=new Runnable() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        watchOnlineUsers(cbox);
                        watchInbox();
                        watchLastMessage();
                        watchFirstMessage();
                    }
                });
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException iz){
                    iz.printStackTrace();
                }
            }
        };
        Thread prikaziPromjene = new Thread(akcija);
        prikaziPromjene.setDaemon(true);
        prikaziPromjene.start();
    }
    public List onlineUsers(){
        List<String>lines=new ArrayList<>();
        try{
            BufferedReader br = new BufferedReader(new FileReader("/home/boki95/Desktop/ProjektniKriptografija-Intellj/PrijavljeniKorisnici.txt"));
            String line = br.readLine();
            while (line != null) {
                {
                    if(!korisnik.getName().contentEquals(line))
                    lines.add(line);
                }
                line = br.readLine();
            }
            list=lines;
        }catch(IOException exe){exe.printStackTrace();}
        return lines;
    }
    public void setChoiceBox(List l){
        this.cbox.setItems(FXCollections.observableList(l));
    }
    public  X509Certificate getCertificate(File file) {
        X509Certificate certificate = null;
        CertificateFactory factory;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            factory = CertificateFactory.getInstance("X.509");
            certificate = (X509Certificate) factory.generateCertificate(fis);
        } catch (Exception ex) {
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException ex) {
                }
            }
        }
        return certificate;
    }
    public boolean provjeraSertifikata(String username,String text,String kome)  {
        String koSalje=hashSHA256(username);
        File crlFile=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/"+"rootcrl.pem");
        File rootCa=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/"+"caSertifikat.pem");
        X509CRL crl;
        FileInputStream fis;
        File f=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/"+koSalje+".pem");
        X509Certificate primalac=getCertificate(f);
        X509Certificate rootCert=getCertificate(rootCa);
        X509CRLEntry povuceni;
        try {
            CertificateFactory cf=CertificateFactory.getInstance("X.509");
            fis=new FileInputStream(crlFile);
            crl=(X509CRL) cf.generateCRL(fis);
            BigInteger serialNumber;
            if(crl!=null){
                serialNumber=primalac.getSerialNumber();
                povuceni=crl.getRevokedCertificate(serialNumber);
                if(povuceni!=null){
                    Alert alert=new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Sertifikat je povucen");
                    alert.showAndWait();
                    return false;
                }
            }
        }catch (Exception e){e.printStackTrace();}
        PublicKey caPublicKey=rootCert.getPublicKey();
        try{
            primalac.verify(caPublicKey);
            primalac.checkValidity();
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
            alert.setResizable(true);
            alert.setHeaderText(kome);
            String version = System.getProperty("java.version");
            String content = String.format(text,version);

            Text sadrzaj =new Text(content);
            sadrzaj.setWrappingWidth(250);
            alert.getDialogPane().setContent(sadrzaj);
            alert.showAndWait();

            return true;
        }catch(NoSuchAlgorithmException|InvalidKeyException|NoSuchProviderException|SignatureException ex){
          Alert alert=new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Sertifikat nije validan");
                    alert.showAndWait();
        return false;}catch(CertificateExpiredException cee){
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Sertifikat je istekao");
            alert.showAndWait();
            return false;
        }catch (CertificateNotYetValidException cnye){
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Sertifikat nije jos vazeci");
            alert.showAndWait();
            return false;
        }catch(CertificateException ce){
            ce.printStackTrace();
            return false;
        }

    }
    public void setArea(String text){
        long pocetak = System.currentTimeMillis();
        Date instant=new Date(pocetak);
        SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm" );
        String time = sdf.format( instant );
        String dekriptovano=decrypt(text);
        String pomoc=sagovornik+": "+dekriptovano+"          "+time;
        tArea.appendText(pomoc+"\n");
    }
    @FXML
    public void uspostaviKonekciju() throws IOException {
        sagovornik=cbox.getValue().toString();
        String datotekaSagovornika=hashSHA256(sagovornik);
        String datotekaMene=hashSHA256(korisnik.getName());
        File file1=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slika.png");
        File file2=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slikacopy.png");
        Files.copy(file1.toPath(), file2.toPath());
        File movingFile=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+datotekaSagovornika+"/slika.png");
        String text;
        text=algoritam+"#"+kljuc;
        String tekstZaSliku="";
        Random rand=new Random();
        int slucajanBroj=rand.nextInt(3);
        if(slucajanBroj==1){
            tekstZaSliku=hashSHA512(text);
        }
        else if(slucajanBroj==2){
            tekstZaSliku=hashSHA256(text);
        }else{
            tekstZaSliku=hashMD5(text);
        }
        Steganografija st=new Steganografija();
        st.encode("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slikacopy.png",tekstZaSliku);
        File mojaSlika=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+datotekaMene+"/slika.png");
        if(algoritamSagovornika.equals(""))
        {
            provjeraSertifikata(sagovornik,"Sertifikat je validan, mozete da komunicirate sa ovim sagovornikom",sagovornik);
            provjeraSertifikata(korisnik.getName(),"Sertifikat korisnika"+korisnik.getName()+" je validan i zeli da komunicira sa vama, ako i vi isto zelite uspostavite komunikaciju",korisnik.getName());
            Files.move(file2.toPath(),movingFile.toPath());
            file2.delete();
            uspostavljenaKonekcija=true;
            tField.setDisable(false);
        }
        else{
            provjeraSertifikata(korisnik.getName(),"Sertifikat je validan, mozete komunicirati",korisnik.getName());
            Files.move(file2.toPath(),movingFile.toPath());
            file2.delete();
            uspostavljenaKonekcija=true;
            tField.setDisable(false);
        }
    }
    private  void watchInbox() {
        String hashKorisnik=hashSHA256(korisnik.getName());
        File dir = new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+hashKorisnik);
        MessageWatcher watcher = new MessageWatcher(dir,this,sagovornik,potpisFajla);
        if (dir.exists()) {
            Thread nit = new Thread(watcher);
            nit.setDaemon(true);
            nit.start();
        }
    }
    public void watchLastMessage(){
        String hashKorisnika=hashSHA256(korisnik.getName());
        File dir=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+hashKorisnika);
        LastMessageWatcher watcher=new LastMessageWatcher(dir,this);
        if(dir.exists()){
            Thread nit=new Thread(watcher);
            nit.setDaemon(true);
            nit.start();
        }
    }
    public void watchFirstMessage(){
        String hashKorisnika=hashSHA256(korisnik.getName());
        File dir=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+hashKorisnika);
        FirstMessageWatcher watcher=new FirstMessageWatcher(dir,this);
        if(dir.exists()){
            Thread nit=new Thread(watcher);
            nit.setDaemon(true);
            nit.start();
        }
    }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashSHA512(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashMD5(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    @FXML
    public void prekiniKonekciju() throws IOException {
        String datotekaSagovornika=hashSHA256(sagovornik);
        File file1=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slika.png");
        File file2=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slikacopy.png");
        Files.copy(file1.toPath(), file2.toPath());
        File movingFile=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+datotekaSagovornika+"/slika2.png");
        String text="KOMUNIKACIJA SE ZAVRSILA!";
        String tekstZaSliku="";
        Random rand=new Random();
        int slucajanBroj=rand.nextInt(3);
        if(slucajanBroj==1){
            tekstZaSliku=hashSHA512(text);
        }
        else if(slucajanBroj==2){
            tekstZaSliku=hashSHA256(text);
        }else{
            tekstZaSliku=hashMD5(text);
        }
        Steganografija st=new Steganografija();
        st.encode("/home/boki95/Desktop/ProjektniKriptografija-Intellj/slikacopy.png",tekstZaSliku);
        Files.move(file2.toPath(),movingFile.toPath());
        file2.delete();
         uspostavljenaKonekcija=false;
    }
    public void obustaviKomuniciranje(String tekst){
        uspostavljenaKonekcija=false;
      tField.setText(null);
        tArea.appendText(tekst+"\n");
    }
    public  PrivateKey getPemPrivateKey(String privateKey) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        File f = new File(privateKey);
        FileInputStream fis = new FileInputStream(f);
        DataInputStream dis = new DataInputStream(fis);
        byte[] keyBytes = new byte[(int) f.length()];
        dis.readFully(keyBytes);
        dis.close();
        String temp = new String(keyBytes);
        StringBuilder pkcs8Lines = new StringBuilder();
        BufferedReader rdr = new BufferedReader(new StringReader(temp));
        String line;
        while ((line = rdr.readLine()) != null) {
            pkcs8Lines.append(line);
        }
        String pkcs8Pem = new String(pkcs8Lines);
        pkcs8Pem = pkcs8Pem.replace("-----BEGIN RSA PRIVATE KEY-----", "");
        pkcs8Pem = pkcs8Pem.replace("-----END RSA PRIVATE KEY-----", "");
        byte[] base64DecodedData = Base64.getMimeDecoder().decode(pkcs8Pem.trim());
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(base64DecodedData);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privKey = kf.generatePrivate(keySpec);
        return privKey;
    }
    public  String sign(File choosenFile, PrivateKey loggedUserPrivateKey, String hashAlgorithm) {
        String encodedSignature = null;
        FileInputStream fis = null;
        try {
            Signature signature = Signature.getInstance(hashAlgorithm);
            signature.initSign(loggedUserPrivateKey);
            fis = new FileInputStream(choosenFile);
            byte[] buffer = new byte[1024];
            int count;
            while ((count = fis.read(buffer)) > 0) {
                signature.update(buffer, 0, count);
            }
            byte[] signatureBytes = signature.sign();
            encodedSignature = new String(Base64.getEncoder().encode(signatureBytes));
            fis.close();
        } catch (IOException | InvalidKeyException | NoSuchAlgorithmException | SignatureException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return encodedSignature;
    }
    public  byte[] encryptAsymmetric(PublicKey receiverPublicKey, byte[] input, File output) {
        byte[] toWrite = null;
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, receiverPublicKey);
            FileOutputStream fos = new FileOutputStream(output);
            toWrite = cipher.doFinal(input);
            fos.write(toWrite);
            fos.flush();
            fos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            return toWrite;
        }
    }
    public static byte[] getFileInBytes(File f) throws IOException {
        FileInputStream fis = new FileInputStream(f);
        byte[] fbytes = new byte[(int) f.length()];
        fis.read(fbytes);
        fis.close();
        return fbytes;
    }

}
