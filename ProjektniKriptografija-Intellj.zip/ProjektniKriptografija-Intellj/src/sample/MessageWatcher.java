package sample;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class MessageWatcher extends Thread{
    private  final File file;
    private String potpisFajla;
    private static UserModeController userController;
    private AtomicBoolean stop= new AtomicBoolean(false);
    private String sagovornik;
    public MessageWatcher(File filee,UserModeController uc,String ime,String potpisFajla){
        this.file=filee;
        this.userController=uc;
        this.sagovornik=ime;
        this.potpisFajla=potpisFajla;
    }
    public boolean isStopped() {
        return stop.get();
    }
    public void stopThread() {
        stop.set(true);
    }
    public void doOnChange() throws Exception {
        String mojHash = hashSHA256(userController.getKorisnikName());
        String njegovHash=hashSHA256(userController.getSagovornik());
        File njegovCert=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/" + njegovHash + ".pem");
        File signature=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" +  mojHash+ "/signature.txt");
        PublicKey njegovPub=getCertificate(njegovCert).getPublicKey();
        String line;

        PrivateKey privK=getPemPrivateKey("/home/boki95/Desktop/ProjektniKriptografija-Intellj/CA/" + mojHash + "4096.key");
        File file2=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + mojHash + "/cryptovano.txt");
        File file3= new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + mojHash + "/decryptovano.txt");
        decryptAsymmetric(privK,getFileInBytes(file2),file3);

        BufferedReader br=new BufferedReader(new FileReader("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + mojHash + "/decryptovano.txt"));
        String text=br.readLine();
        br.close();
        File file = new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/" + mojHash + "/poruka.txt");
        br.close();
        if(verifySignature(file3,njegovPub,signature,"SHA512withRSA")) {
            userController.setArea(text);
        }
        signature.delete();
        file.delete();
        file2.delete();
        file3.delete();
    }
     @Override
    public  void run(){
        try(WatchService watcher= FileSystems.getDefault().newWatchService()){
            Path path=file.toPath();
            path.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
            while(!isStopped()){
                WatchKey key;
                try{
                    key=watcher.poll(25, TimeUnit.MILLISECONDS);
                }catch(InterruptedException ie){return;}
                if(key==null){
                    Thread.yield();
                    continue;
                }
                for(WatchEvent<?> event:key.pollEvents()){
                    WatchEvent.Kind<?>kind=event.kind();
                    WatchEvent<Path>ev =(WatchEvent<Path>)event;
                    Path filename=ev.context();
                    if(kind==StandardWatchEventKinds.OVERFLOW){
                        Thread.yield();
                        continue;
                    }
                    else if(kind==StandardWatchEventKinds.ENTRY_CREATE&&filename.toString().startsWith("poruka.txt")){
                        doOnChange();
                    }
                    boolean valid=key.reset();
                    if(!valid){
                        break;
                    }
                }
                Thread.yield();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
     }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public static boolean verifySignature(File decryptedFile, PublicKey publicKey, File receivedSignature, String hashAlgorithmForSign) {
        Signature sig;
        try {
            sig = Signature.getInstance(hashAlgorithmForSign);
            sig.initVerify(publicKey);
            BufferedInputStream bufin = new BufferedInputStream(new FileInputStream(decryptedFile));

            byte[] buffer = new byte[1024];
            int len;
            while (bufin.available() != 0) {
                len = bufin.read(buffer);
                sig.update(buffer, 0, len);
            }
            bufin.close();
            byte[] signedBytes = Files.readAllBytes(receivedSignature.toPath());
            byte signature[] = Base64.getDecoder().decode(signedBytes);

            if (signature.length != 512)
                return false;
            boolean verifies = sig.verify(signature);
            return verifies;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public static X509Certificate getCertificate(File file) {
        X509Certificate certificate = null;
        CertificateFactory factory;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            factory = CertificateFactory.getInstance("X.509");
            certificate = (X509Certificate) factory.generateCertificate(fis);
        } catch (Exception ex) {
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException ex) {
                }
            }
        }
        return certificate;
    }
    public static PrivateKey getPemPrivateKey(String privateKey) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        File f = new File(privateKey);
        FileInputStream fis = new FileInputStream(f);
        DataInputStream dis = new DataInputStream(fis);
        byte[] keyBytes = new byte[(int) f.length()];
        dis.readFully(keyBytes);
        dis.close();

        String temp = new String(keyBytes);
        StringBuilder pkcs8Lines = new StringBuilder();
        BufferedReader rdr = new BufferedReader(new StringReader(temp));
        String line;
        while ((line = rdr.readLine()) != null) {
            pkcs8Lines.append(line);
        }

        // Remove the "BEGIN" and "END" lines, as well as any whitespace
        String pkcs8Pem = new String(pkcs8Lines);//pkcs8Lines.toString();
        pkcs8Pem = pkcs8Pem.replace("-----BEGIN RSA PRIVATE KEY-----", "");
        pkcs8Pem = pkcs8Pem.replace("-----END RSA PRIVATE KEY-----", "");

        // Base64 decode the resultBase64.getMimeDecoder().decode(authInfo);
        byte[] base64DecodedData = Base64.getMimeDecoder().decode(pkcs8Pem.trim());

        // extract the private key
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(base64DecodedData);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privKey = kf.generatePrivate(keySpec);
        return privKey;
    }
    public static void decryptAsymmetric(PrivateKey privateKey, byte[] input, File output) {
        try {
            if (!output.exists()) {
                output.createNewFile();
            }
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] toWrite = cipher.doFinal(input);
            FileOutputStream fos = new FileOutputStream(output);
            fos.write(toWrite);
            fos.flush();
            fos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public static byte[] getFileInBytes(File f) throws IOException {
        FileInputStream fis = new FileInputStream(f);
        byte[] fbytes = new byte[(int) f.length()];
        fis.read(fbytes);
        fis.close();
        return fbytes;
    }
}
