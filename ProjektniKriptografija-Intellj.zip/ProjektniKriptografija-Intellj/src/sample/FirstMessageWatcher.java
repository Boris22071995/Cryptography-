package sample;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class FirstMessageWatcher extends Thread {
    private  String algoritamSagovornika="";
    private String kljucSagovornika="";
    private final File file;
    private static UserModeController userController;
    private AtomicBoolean stop=new AtomicBoolean(false);
    public FirstMessageWatcher(File file,UserModeController uc){
        this.file=file;
        this.userController=uc;
    }
    public boolean isStopped(){
        return stop.get();
    }
    public void stopThread(){
        stop.set(true);
    }
    public void doOnChange(){
        Steganografija st=new Steganografija();
        String korisnickiFajl=hashSHA256(userController.getKorisnikName());
        String textIzSlike=st.decode("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+ korisnickiFajl+ "/slika.png");
        File file=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+ korisnickiFajl+ "/slika.png");
        decodeText(textIzSlike);
        userController.postaviPodatkeIzSluke(this.algoritamSagovornika,this.kljucSagovornika);
        file.delete();
    }
    @Override
    public void run(){
        try(WatchService watcher= FileSystems.getDefault().newWatchService()){
            Path path=file.toPath();
            path.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
            while(!isStopped()){
                WatchKey key;
                try{
                    key=watcher.poll(25, TimeUnit.MILLISECONDS);
                }catch(InterruptedException ie){return;}
                if(key==null){
                    Thread.yield();
                    continue;
                }
                for(WatchEvent<?> event:key.pollEvents()){
                    WatchEvent.Kind<?>kind=event.kind();
                    WatchEvent<Path>ev=(WatchEvent<Path>)event;
                    Path filename=ev.context();
                    if(kind==StandardWatchEventKinds.OVERFLOW){
                        Thread.yield();
                        continue;
                    }else if(kind==StandardWatchEventKinds.ENTRY_CREATE&&filename.toString().startsWith("slika.png")){
                        doOnChange();
                    }
                    boolean valid=key.reset();
                    if(!valid){
                        break;
                    }
                }
                Thread.yield();
            }
        }catch (IOException e){e.printStackTrace();}
    }
    public void decodeText(String poruka) {
        String al1="AES";
        String al2="DES";
        String al3="Blowfish";
        String k1="kriptografija";
        String k2="sigurnost";
        String k3="zastita";
        if(poruka.equals(hashSHA512(al1+"#"+k1))||poruka.equals(hashSHA256(al1+"#"+k1))|| poruka.equals(hashMD5(al1+"#"+k1))){
            this.algoritamSagovornika=al1;
            this.kljucSagovornika=k1;
        }
        else if(poruka.equals(hashSHA512(al1+"#"+k2))||poruka.equals(hashSHA256(al1+"#"+k2))|| poruka.equals(hashMD5(al1+"#"+k2))){
            this.algoritamSagovornika=al1;
            this.kljucSagovornika=k2;
        }else if(poruka.equals(hashSHA512(al1+"#"+k3))||poruka.equals(hashSHA256(al1+"#"+k3))|| poruka.equals(hashMD5(al1+"#"+k3))){
            this.algoritamSagovornika=al1;
            this.kljucSagovornika=k3;
        }
        else if(poruka.equals(hashSHA512(al2+"#"+k1))||poruka.equals(hashSHA256(al2+"#"+k1))|| poruka.equals(hashMD5(al2+"#"+k1))){
            this.algoritamSagovornika=al2;
            this.kljucSagovornika=k1;
        }
        else if(poruka.equals(hashSHA512(al2+"#"+k2))||poruka.equals(hashSHA256(al2+"#"+k2))|| poruka.equals(hashMD5(al2+"#"+k2))){
            this.algoritamSagovornika=al2;
            this.kljucSagovornika=k2;
        }else if(poruka.equals(hashSHA512(al2+"#"+k3))||poruka.equals(hashSHA256(al2+"#"+k3))|| poruka.equals(hashMD5(al2+"#"+k3))){
            this.algoritamSagovornika=al2;
            this.kljucSagovornika=k3;
        }
        else if(poruka.equals(hashSHA512(al3+"#"+k1))||poruka.equals(hashSHA256(al3+"#"+k1))|| poruka.equals(hashMD5(al3+"#"+k1))){
            this.algoritamSagovornika=al3;
            this.kljucSagovornika=k1;
        }
        else if(poruka.equals(hashSHA512(al3+"#"+k2))||poruka.equals(hashSHA256(al3+"#"+k2))|| poruka.equals(hashMD5(al3+"#"+k2))){
            this.algoritamSagovornika=al3;
            this.kljucSagovornika=k2;
        }else if(poruka.equals(hashSHA512(al3+"#"+k3))||poruka.equals(hashSHA256(al3+"#"+k3))|| poruka.equals(hashMD5(al3+"#"+k3))){
            this.algoritamSagovornika=al3;
            this.kljucSagovornika=k3;
        }

    }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashSHA512(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashMD5(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
}
