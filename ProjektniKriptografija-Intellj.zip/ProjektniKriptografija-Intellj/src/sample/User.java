package sample;

import java.util.Random;

public class User {
    private static String name;
    public  static boolean online=false;
    public static String algoritam;
    public static String kljuc;
    public User(String name) {
        this.name=name;
        this.online=true;
        this.algoritam=odrediAlgoritam();
        this.kljuc=kljucevi();
    }
    public User() {
    }
    public String getName() {
        return this.name;
    }
    public String getAlgoritam(){return this.algoritam;}
    public String getKljuc(){return this.kljuc;}
    public boolean getOnline(){return online;}
    public String odrediAlgoritam() {
        Random rand =new Random();
        int broj=rand.nextInt(3);
        if((broj+1)==1) {
            return "AES";
        }
        else if((broj+1)==2) {
            return "Blowfish";
        }
        else if((broj+1)==3) {
            return "DES";
        }
        else return "";
    }
    public String kljucevi() {
        Random rand =new Random();
        int broj=rand.nextInt(3);
        if((broj+1)==1) {
            return "kriptografija";
        }
        else if((broj+1)==2) {
            return "sigurnost";
        }
        else if((broj+1)==3) {
            return "zastita";
        }
        else return "";
    }
}
