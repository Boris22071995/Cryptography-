package sample;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Node;

public class LoginController {
    @FXML
    private Button registracija;
    @FXML
    private Button izadji;
    @FXML
    private Button prijava;
    @FXML
    private TextField imeKorisnika;
    @FXML
    private PasswordField sifra;
    private UserModeController uController=new UserModeController();
    @FXML
    public void otvoriRegistraciju(ActionEvent ae) {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("Registration.fxml"));
            Scene scene = new Scene(root,339,332);
            Stage stage = (Stage) ((Node) ae.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("CryptoChat");
            stage.show();
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
    @FXML
    public void zatvoriFormu() {
        Stage stage = (Stage) izadji.getScene().getWindow();
        stage.hide();
    }
    public boolean provjeraValidnosti(String ime,String password) {
        String user=imeKorisnika.getText();
        String hashPassword512=hashSHA512(password);
        String hashPassword256=hashSHA256(password);
        String hashPasswordMD5=hashMD5(password);
        boolean validnost=false;
            try{
                List<String>lines=new ArrayList<>();
                BufferedReader br=new BufferedReader(new FileReader("/home/boki95/Desktop/ProjektniKriptografija-Intellj/RegistrovaniKorisnici.txt"));
                String line=br.readLine();
                while(line!=null){
                    lines.add(line);
                    line=br.readLine();
                }
                int pom=lines.size();
                String text1=user+hashPassword512;
                String text2=user+hashPassword256;
                String text3=user+hashPasswordMD5;
                for(int i=0;i<pom;i++){
                    String temp=lines.remove(0);
                    if(text1.contentEquals(temp)){validnost=true;}
                    else if(text2.contentEquals(temp)){validnost=true;}
                    else if(text3.contentEquals(temp)){validnost=true;}
                }
            }catch(IOException ioe){ioe.printStackTrace();}
        return validnost;
    }
    @FXML
    public void prijavaNaSistem(ActionEvent ae) {
        if (imeKorisnika.getText().isEmpty() || sifra.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setHeaderText(null);
                            alert.setContentText("Morate popuniti sva polja.");
                            alert.showAndWait();
            return;
        }
        if (provjeraValidnosti(imeKorisnika.getText(),sifra.getText())){
            try{
                FileWriter fw = new FileWriter("/home/boki95/Desktop/ProjektniKriptografija-Intellj/PrijavljeniKorisnici.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter pw = new PrintWriter(bw);
                pw.println(imeKorisnika.getText());
                pw.flush();
                pw.close();
            }catch(IOException ioe){ioe.printStackTrace();}
            try{
                File files = new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/PrijavljeniKorisnici.txt");
                User korisnik = new User(imeKorisnika.getText());
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UserMode.fxml"));
                Parent root = (Parent) loader.load();
                Scene scene = new Scene(root, 551, 400);
                uController = loader.getController();
                uController.izmjeni(files);
                Stage stage = (Stage) ((Node) ae.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.setTitle("CryptoChat");
                stage.show();
                imeKorisnika.setText(null);
                sifra.setText(null);
            }catch(Exception e){e.printStackTrace();}
        }
        else{
                Alert alert=new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Uneseni podaci nisu validni");
                alert.showAndWait();
        }
    }
    public String hashSHA512(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashMD5(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
}
