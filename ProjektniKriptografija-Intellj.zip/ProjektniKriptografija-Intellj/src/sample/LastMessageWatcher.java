package sample;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class LastMessageWatcher extends Thread {
    private final File file;
    private static UserModeController userController;
    private AtomicBoolean stop=new AtomicBoolean(false);
    public LastMessageWatcher(File file, UserModeController uc){
        this.file=file;
        this.userController=uc;
    }
    public boolean isStopped(){
        return stop.get();
    }
    public void stopThread(){
        stop.set(true);
    }
    public void doOnChange(){
        String korisnickiFajl=hashSHA256(userController.getKorisnikName());
        Steganografija st=new Steganografija();
        String tekst=st.decode("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+ korisnickiFajl+ "/slika2.png");
        File file=new File("/home/boki95/Desktop/ProjektniKriptografija-Intellj/"+ korisnickiFajl+ "/slika2.png");
        String izSlikeDekodovano="KOMUNIKACIJA SE ZAVRSILA!";
        if(tekst.equals(hash512(izSlikeDekodovano))||tekst.equals(hashSHA256(izSlikeDekodovano))||tekst.equals(hashMD5(izSlikeDekodovano))){
            userController.obustaviKomuniciranje(izSlikeDekodovano);
            file.delete();
        }
    }
    @Override
    public void run(){
        try(WatchService watcher= FileSystems.getDefault().newWatchService()){
            Path path=file.toPath();
            path.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
            while(!isStopped()){
                WatchKey key;
                try{
                    key=watcher.poll(25, TimeUnit.MILLISECONDS);
                }catch(InterruptedException ie){return;}
                if(key==null){
                    Thread.yield();
                    continue;
                }
                for(WatchEvent<?> event:key.pollEvents()){
                    WatchEvent.Kind<?>kind=event.kind();
                    WatchEvent<Path>ev=(WatchEvent<Path>)event;
                    Path filename=ev.context();
                    if(kind==StandardWatchEventKinds.OVERFLOW){
                        Thread.yield();
                        continue;
                    }else if(kind==StandardWatchEventKinds.ENTRY_CREATE&&filename.toString().startsWith("slika2.png")){
                        doOnChange();
                    }
                    boolean valid=key.reset();
                    if(!valid){
                        break;
                    }
                }
                Thread.yield();
            }
        }catch (IOException e){e.printStackTrace();}
    }
    public String hashSHA256(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hash512(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-512");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
    public String hashMD5(String text){
        String hashText="";
        try{
            MessageDigest md=MessageDigest.getInstance("MD5");
            byte[]messageDigest=md.digest(text.getBytes());
            BigInteger no=new BigInteger(1,messageDigest);
            hashText=no.toString(16);
            while(hashText.length()<32){
                hashText="0"+hashText;
            }
        }catch (Exception e){e.printStackTrace();}
        return hashText;
    }
}
